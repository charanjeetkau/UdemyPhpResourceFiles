<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>While Loops</title>
</head>
<body>

<?php 

$counter = 0;
while($counter <= 10 ){

    echo $counter;
    $counter++;
//    $counter = $counter + 1;

}



?>



</body>
</html>