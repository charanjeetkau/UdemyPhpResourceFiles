*************


I put all the lecture files in the the lecture files folder to organize a little.
In the next lectures, Edwin from the past still shows the lecture files in the main
demo folder, but that’s ok since we already know where they are :) 



**************


************* Use Lecture files for class reference **************


************* Have suggestions or comments? support@codingfaculty.com **************

************* Want to read my BLOG ? EdwinDiaz.com **************